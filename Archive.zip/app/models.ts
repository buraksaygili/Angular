import { TodoItem } from "./todoitems";

export class Models{
    name: string;
    items: TodoItem[];

    constructor(){
        this.name="Sadik";
        this.items = [
            {description: "Kahvalti", action: true},
            {description: "Spor", action: true},
            {description: "Alisveris", action: false},
        ];

    }
   
}

