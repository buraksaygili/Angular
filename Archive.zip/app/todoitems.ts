// export class TodoItem{
//     constructor(public description: string, public action: string){
//         this.description=description;
//         this.action=action;
//     }
// }

export interface TodoItem{
     description: string;
     action: boolean;
}
